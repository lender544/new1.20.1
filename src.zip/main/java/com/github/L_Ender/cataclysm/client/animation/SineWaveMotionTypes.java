package com.github.L_Ender.cataclysm.client.animation;

public enum SineWaveMotionTypes {
	ROTATION_X,
	ROTATION_Y,
	ROTATION_Z,
	POSITION_X,
	POSITION_Y,
	POSITION_Z,
	SCALE_X,
	SCALE_Y,
	SCALE_Z
}
